class Two1SellNotSupportedException(Exception):
    pass
