ps aux | grep zerotier
