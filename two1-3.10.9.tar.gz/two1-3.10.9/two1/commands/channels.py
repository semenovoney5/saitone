"""Shim to include channels into two1.commands."""
from two1.channels.cli import main as channels

if __name__ == "__main__":
    channels()
